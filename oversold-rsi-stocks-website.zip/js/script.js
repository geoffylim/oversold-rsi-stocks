document.addEventListener("DOMContentLoaded", function() {
    console.log("Oversold RSI Stocks site loaded.");
    // Placeholder: In the future, fetch live stock data here
});
